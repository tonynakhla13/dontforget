---
name: sky-sham-design
description: Use this skill to generate well-branded interfaces and assets for Sky Sham (Sama Al Sham · Travel & Tours), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key facts to honour:
- **Sky Sham · Travel & Tours** (Arabic heritage name *Sama Al Sham*) is an **inquiry-based** UAE travel platform — flights, hotels, tour packages, Umrah and visa services. Prices in **AED**. It **never takes payment online**; every CTA is an *inquiry* ("Send Inquiry", "Inquire →").
- **Type:** Bebas Neue (display: hero 64 / section 44 / card 32) + Montserrat (UI: H1 24·700, H2 18·700, H3 15·600, body 14/12, labels 10·700 uppercase). Both load from Google Fonts via `colors_and_type.css`.
- **Color:** brand blue `#4EAEFF` (CTAs as `#4FABFF→#1A73DB` gradient); orange accent family `#FF9D2E / #F47C20` for offers & highlights; cool neutrals; deep-navy "night" surfaces for hero bands and premium cards.
- **Foundations:** 4px spacing grid; radius sm4/md8/lg12/xl16/2xl20-24/pill; soft cool shadows + colored CTA glows; Lucide icons.
- Always pull tokens from `colors_and_type.css`; use the official logo at `assets/sky-sham-logo.png` (place on a white safe-area chip over dark surfaces).
