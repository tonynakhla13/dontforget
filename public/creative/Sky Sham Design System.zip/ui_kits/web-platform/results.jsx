// results.jsx — Results view: breadcrumb, filter rail, flight rows / hotel cards
const { useState: useStateRes } = React;

const FLIGHTS = [
  { code: "EK", airline: "Emirates", type: "Direct · Economy", dep: "08:00", from: "DXB", arr: "15:20", to: "IST", dur: "7h 20m", price: "1,540", best: true },
  { code: "TK", airline: "Turkish Airlines", type: "Direct · Economy", dep: "11:45", from: "DXB", arr: "16:55", to: "IST", dur: "5h 10m", price: "1,720" },
  { code: "G9", airline: "Air Arabia", type: "1 Stop · Economy", dep: "02:15", from: "SHJ", arr: "12:40", to: "IST", dur: "9h 25m", price: "990" },
];

const HOTELS = [
  { name: "Grand Hyatt Istanbul", loc: "Beşiktaş, Istanbul", inc: "Breakfast + WiFi included", price: "620", rating: 5, status: "Available", grad: "linear-gradient(135deg,#0F2E85,#1F73C7 55%,#2EB8D6)" },
  { name: "CVK Park Bosphorus", loc: "Taksim, Istanbul", inc: "Sea view · Spa access", price: "540", rating: 4, status: "Available", grad: "linear-gradient(135deg,#3A1D5E,#6A3FA0 55%,#A06ED6)" },
  { name: "Hilton Istanbul Bomonti", loc: "Şişli, Istanbul", inc: "Breakfast included", price: "430", rating: 4, status: "Limited", grad: "linear-gradient(135deg,#0B3B2E,#1E7A5E 55%,#3BB78F)" },
];

function Breadcrumb({ items }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, font: "600 13px var(--font-ui)" }}>
      {items.map((it, i) => (
        <React.Fragment key={i}>
          <span style={{ color: i === items.length - 1 ? "var(--black)" : "var(--blue-primary)" }}>{it}</span>
          {i < items.length - 1 && <Icon name="chevronRight" size={14} color="var(--gray-300)" />}
        </React.Fragment>
      ))}
    </div>
  );
}

function FilterPanel({ tab }) {
  const [range, setRange] = useStateRes(60);
  const airlines = [["Emirates", true], ["Air Arabia", true], ["Fly Dubai", false], ["Turkish Airlines", false]];
  return (
    <aside style={{ flex: "0 0 248px", background: "#fff", border: "1px solid var(--border)",
                    borderRadius: "var(--radius-xl)", padding: 20, height: "fit-content", position: "sticky", top: 92 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 8, font: "700 16px var(--font-ui)", color: "var(--black)" }}>
          <Icon name="sliders" size={18} color="var(--blue-primary)" /> Filters
        </span>
        <button style={{ border: "none", background: "transparent", color: "var(--blue-primary)", font: "700 12px var(--font-ui)", cursor: "pointer" }}>Reset</button>
      </div>
      <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)" }}>Price range</div>
      <div style={{ font: "600 13px var(--font-ui)", color: "var(--black)", margin: "8px 0 10px" }}>AED 0 — {(range * 83).toLocaleString()}</div>
      <input type="range" min="0" max="100" value={range} onChange={(e) => setRange(+e.target.value)}
             style={{ width: "100%", accentColor: "var(--blue-primary)" }} />
      <div style={{ height: 1, background: "var(--border)", margin: "18px 0" }} />
      <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)", marginBottom: 12 }}>
        {tab === "Hotels" ? "Star rating" : "Airline"}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {airlines.map(([name, on]) => (
          <label key={name} style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", font: "500 13px var(--font-ui)", color: "var(--gray-dark)" }}>
            <span style={{ width: 18, height: 18, borderRadius: 5, border: on ? "none" : "1.5px solid var(--gray-300)",
                           background: on ? "var(--blue-primary)" : "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {on && <Icon name="check" size={13} color="#fff" strokeWidth={3} />}
            </span>
            {name}
          </label>
        ))}
      </div>
      <div style={{ height: 1, background: "var(--border)", margin: "18px 0" }} />
      <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)", marginBottom: 10 }}>Stops</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {["Direct", "1 Stop", "2+ Stops"].map((s, i) => (
          <span key={s} style={{ font: "600 11px var(--font-ui)", padding: "7px 12px", borderRadius: 999,
                                 border: "1px solid var(--border)", color: i === 0 ? "var(--blue-primary)" : "var(--gray-dark)",
                                 background: i === 0 ? "var(--blue-surface)" : "#fff", cursor: "pointer" }}>{s}</span>
        ))}
      </div>
    </aside>
  );
}

function FlightRow({ f, onInquire }) {
  return (
    <div style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)",
                  padding: "18px 22px", display: "flex", alignItems: "center", gap: 24, boxShadow: "var(--shadow-sm)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, flex: "0 0 200px" }}>
        <div style={{ width: 46, height: 46, borderRadius: "var(--radius-md)", background: "var(--blue-surface)",
                      display: "flex", alignItems: "center", justifyContent: "center", font: "700 14px var(--font-ui)", color: "var(--blue-deep)" }}>{f.code}</div>
        <div><div style={{ font: "700 15px var(--font-ui)", color: "var(--black)" }}>{f.airline}</div>
             <div style={{ font: "500 12px var(--font-ui)", color: "var(--gray)" }}>{f.type}</div></div>
      </div>
      <div style={{ textAlign: "center" }}><div style={{ font: "700 22px var(--font-ui)", color: "var(--black)" }}>{f.dep}</div><div style={{ font: "500 11px var(--font-ui)", color: "var(--gray)" }}>{f.from}</div></div>
      <div style={{ flex: 1, textAlign: "center" }}>
        <div style={{ font: "500 11px var(--font-ui)", color: "var(--gray)", marginBottom: 5 }}>{f.dur}</div>
        <div style={{ position: "relative", height: 2, background: "var(--border)" }}>
          <span style={{ position: "absolute", right: 0, top: -4, width: 9, height: 9, borderRadius: 999, background: "var(--blue-primary)" }} />
          <Icon name="plane" size={14} color="var(--blue-primary)" style={{ position: "absolute", left: "50%", top: -7, transform: "translateX(-50%)" }} />
        </div>
      </div>
      <div style={{ textAlign: "center" }}><div style={{ font: "700 22px var(--font-ui)", color: "var(--black)" }}>{f.arr}</div><div style={{ font: "500 11px var(--font-ui)", color: "var(--gray)" }}>{f.to}</div></div>
      <div style={{ flex: "0 0 130px", textAlign: "right" }}>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "var(--blue-deep)", lineHeight: 1 }}>AED {f.price}</div>
        {f.best && <div style={{ font: "600 11px var(--font-ui)", color: "var(--success)", marginTop: 3 }}>Best price today</div>}
      </div>
      <Button variant="primary" size="md" onClick={() => onInquire({ place: f.airline + " · DXB→IST", price: f.price, loc: "Flight inquiry" })}>Inquire →</Button>
    </div>
  );
}

function HotelRow({ h, onInquire }) {
  return (
    <div style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-xl)",
                  overflow: "hidden", display: "flex", boxShadow: "var(--shadow-sm)" }}>
      <div style={{ flex: "0 0 170px", background: h.grad }} />
      <div style={{ flex: 1, padding: "18px 20px" }}>
        <div style={{ font: "700 17px var(--font-ui)", color: "var(--blue-deep)" }}>{h.name}</div>
        <div style={{ margin: "7px 0" }}><Stars value={h.rating} /> <span style={{ font: "600 12px var(--font-ui)", color: "var(--gray-dark)", marginLeft: 6 }}>{h.loc}</span></div>
        <div style={{ font: "500 13px var(--font-ui)", color: "var(--gray-dark)" }}>{h.inc}</div>
        <Badge tone={h.status === "Available" ? "success" : "warning"} dot style={{ marginTop: 12 }}>{h.status}</Badge>
      </div>
      <div style={{ flex: "0 0 170px", padding: "18px 20px", display: "flex", flexDirection: "column", alignItems: "flex-end", justifyContent: "space-between" }}>
        <div style={{ textAlign: "right" }}><div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "var(--blue-deep)", lineHeight: 1 }}>AED {h.price}</div><div style={{ font: "500 11px var(--font-ui)", color: "var(--gray)" }}>/ night</div></div>
        <Button variant="outline" size="sm" full onClick={() => onInquire({ place: h.name, price: h.price, loc: h.loc })}>Inquire →</Button>
      </div>
    </div>
  );
}

function ResultsView({ tab, onInquire }) {
  const isHotels = tab === "Hotels";
  return (
    <div style={{ background: "var(--bg-page)", minHeight: "70vh" }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "26px 28px 64px" }}>
        <Breadcrumb items={["Home", tab, "Istanbul, Turkey"]} />
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", margin: "18px 0 24px" }}>
          <h1 style={{ font: "700 24px var(--font-ui)", color: "var(--black)", margin: 0 }}>
            {isHotels ? "Hotels in Istanbul" : "Dubai → Istanbul"} <span style={{ color: "var(--gray)", fontWeight: 500, fontSize: 15 }}>· {isHotels ? HOTELS.length : FLIGHTS.length} results</span>
          </h1>
          <div style={{ display: "flex", alignItems: "center", gap: 8, font: "600 13px var(--font-ui)", color: "var(--gray-dark)" }}>
            Sort: <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--blue-primary)" }}>Best value <Icon name="chevronDown" size={15} /></span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 24, alignItems: "flex-start" }}>
          <FilterPanel tab={tab} />
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
            {isHotels
              ? HOTELS.map((h, i) => <HotelRow key={i} h={h} onInquire={onInquire} />)
              : FLIGHTS.map((f, i) => <FlightRow key={i} f={f} onInquire={onInquire} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ResultsView, Breadcrumb });
