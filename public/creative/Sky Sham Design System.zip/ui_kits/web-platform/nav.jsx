// nav.jsx — TopNav + Footer
const { useState: useStateNav } = React;

function TopNav({ onHome, onNav, active = "Flights" }) {
  const links = [
    { label: "Flights", icon: "plane" },
    { label: "Hotels", icon: "bed" },
    { label: "Tours", icon: "map" },
    { label: "Visa", icon: "passport" },
  ];
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 50, background: "rgba(255,255,255,.92)",
                     backdropFilter: "blur(10px)", borderBottom: "1px solid var(--border)" }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", height: 76, padding: "0 28px",
                    display: "flex", alignItems: "center", gap: 32 }}>
        <div style={{ cursor: "pointer" }} onClick={onHome}><Logo height={50} /></div>
        <nav style={{ display: "flex", gap: 6, marginLeft: 12 }}>
          {links.map((l) => {
            const on = active === l.label;
            return (
              <button key={l.label} onClick={() => onNav && onNav(l.label)}
                style={{ display: "flex", alignItems: "center", gap: 7, border: "none", cursor: "pointer",
                         background: on ? "var(--blue-surface)" : "transparent", color: on ? "var(--blue-primary)" : "var(--gray-dark)",
                         font: "600 13px var(--font-ui)", padding: "9px 14px", borderRadius: "var(--radius-md)" }}>
                <Icon name={l.icon} size={16} /> {l.label}
              </button>
            );
          })}
        </nav>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 16 }}>
          <button style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "transparent",
                           color: "var(--gray-dark)", font: "600 13px var(--font-ui)", cursor: "pointer" }}>
            <Icon name="globe" size={16} /> EN · AED
          </button>
          <Button variant="primary" size="sm"><Icon name="phone" size={15} /> Contact Us</Button>
        </div>
      </div>
    </header>
  );
}

function Footer() {
  const cols = [
    { h: "Destinations", items: ["Turkey", "Georgia", "Bali", "Umrah Packages", "GCC Getaways"] },
    { h: "Services", items: ["Flight Booking", "Hotels", "Tour Packages", "Visa Assistance", "B2B Partners"] },
    { h: "Company", items: ["About Sky Sham", "Our Consultants", "Reviews", "Careers", "Contact"] },
  ];
  return (
    <footer style={{ background: "var(--grad-night)", color: "#fff", marginTop: 64 }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "52px 28px 32px",
                    display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", gap: 40 }}>
        <div>
          <Logo height={56} chip />
          <p style={{ font: "400 13px/1.7 var(--font-ui)", color: "#94A3B8", marginTop: 18, maxWidth: 260 }}>
            We craft complete travel experiences for individuals, families and B2B clients — flights, hotels, tours and visas.
          </p>
          <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 6, font: "600 12px var(--font-ui)", color: "#94D2FF" }}>
              <Icon name="phone" size={15} /> +971 4 000 0000
            </span>
          </div>
        </div>
        {cols.map((c) => (
          <div key={c.h}>
            <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".08em", textTransform: "uppercase",
                          color: "#94D2FF", marginBottom: 16 }}>{c.h}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
              {c.items.map((i) => (
                <a key={i} href="#" style={{ font: "400 13px var(--font-ui)", color: "#CBD5E1", textDecoration: "none" }}>{i}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{ borderTop: "1px solid rgba(255,255,255,.1)", padding: "18px 28px" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", display: "flex", justifyContent: "space-between",
                      font: "400 12px var(--font-ui)", color: "#64748B" }}>
          <span>© 2026 Sky Sham · Sama Al Sham Travel & Tours. All rights reserved.</span>
          <span>Inquiry-based travel · No online payment</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { TopNav, Footer });
