// app.jsx — view router for the Sky Sham platform kit
const { useState: useStateApp, useEffect: useEffectApp } = React;

function App() {
  const [view, setView] = useStateApp("home");   // home | results | inquiry | confirmed
  const [tab, setTab] = useStateApp("Flights");
  const [pkg, setPkg] = useStateApp(null);

  useEffectApp(() => { window.scrollTo({ top: 0 }); }, [view]);

  const goResults = () => setView("results");
  const inquire = (p) => { setPkg(p); setView("inquiry"); };

  return (
    <div style={{ fontFamily: "var(--font-ui)", color: "var(--black)", background: "#fff", minHeight: "100vh" }}>
      <TopNav active={tab} onHome={() => setView("home")}
              onNav={(t) => { setTab(t); setView(t === "Visa" ? "inquiry" : "results"); if (t === "Visa") setPkg({ place: "Visa Service", loc: "Turkey · Tourist Visa", price: "350" }); }} />

      {view === "home" && (
        <>
          <HeroSearch tab={tab} setTab={setTab} onSearch={goResults} />
          <StatBar />
          <PackageGrid onInquire={inquire} />
          <ServicesStrip />
        </>
      )}
      {view === "results" && <ResultsView tab={tab} onInquire={inquire} />}
      {view === "inquiry" && <InquiryView pkg={pkg} onSubmit={() => setView("confirmed")} onBack={() => setView(pkg?.place?.includes("Visa") ? "home" : "results")} />}
      {view === "confirmed" && <ConfirmationView pkg={pkg} onHome={() => setView("home")} />}

      <Footer />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
