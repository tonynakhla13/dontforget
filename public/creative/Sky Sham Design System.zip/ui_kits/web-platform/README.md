# Sky Sham — Web Platform UI Kit

A high-fidelity, click-through recreation of the **Sky Sham · Travel & Tours** booking platform — the inquiry-based travel site (flights, hotels, tour packages, visa). Open `index.html` and walk the full journey:

**Home** (hero search + tabs) → **Search** → **Results** (flight rows / hotel cards + filter rail) → **Send Inquiry** (multi-step form + document upload + live summary) → **Inquiry Received** confirmation.

Switching the top-nav tabs changes context (Flights/Hotels/Tours results; Visa jumps straight to an inquiry). Every primary action is an *inquiry* — the platform never takes payment online.

## Files
| File | Contents |
|---|---|
| `index.html` | App shell; loads React + Babel and all component scripts in order. |
| `icons.jsx` | `Icon` + `Stars` — curated **Lucide** glyph set (plane, bed, map, passport, search, calendar, check…). |
| `primitives.jsx` | `Logo` (official PNG mark), `Button` (primary / gold / secondary / outline / ghost), `Badge`, `Field`. |
| `nav.jsx` | `TopNav` (sticky, blurred) + `Footer` (night gradient). |
| `home.jsx` | `HeroSearch`, `StatBar`, `PackageGrid` / `PackageCard` (dark package + orange offer card), `ServicesStrip`. |
| `results.jsx` | `ResultsView`, `FilterPanel`, `FlightRow`, `HotelRow`, `Breadcrumb`. |
| `inquiry.jsx` | `StepIndicator`, `InquiryView` (form + `UploadBox` + summary rail), `ConfirmationView`. |
| `app.jsx` | View router (`home / results / inquiry / confirmed`) + tab state. |

## Conventions
- All color, type, spacing, radius and shadow values come from `../../colors_and_type.css` custom properties — never hard-code brand colors.
- Components share scope via `window` assignment (Babel transpiles each `<script>` in isolation). Each file has a uniquely-named `useState` alias to avoid collisions.
- Bebas Neue for display moments (hero, prices, card titles); Montserrat for all UI text.

## Caveats / to replace with real content
- **Imagery:** destination image areas use brand gradient blocks as stand-ins. The brand calls for **real 3D / photographic destination shots** — drop them into the package/hotel image areas and the hero.
- Data (flights, hotels, packages, prices) is illustrative sample content.
