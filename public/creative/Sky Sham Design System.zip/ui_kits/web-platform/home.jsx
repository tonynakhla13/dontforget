// home.jsx — Hero search, stats, featured packages, services strip
const { useState: useStateHome } = React;

const SEARCH_TABS = [
  { label: "Flights", icon: "plane" },
  { label: "Hotels", icon: "bed" },
  { label: "Tours", icon: "map" },
  { label: "Visa", icon: "passport" },
];

function HeroSearch({ tab, setTab, onSearch }) {
  const [to, setTo] = useStateHome("");
  return (
    <section style={{ background: "var(--grad-night)", position: "relative", overflow: "hidden" }}>
      {/* soft cyan glow accents (placeholder for hero destination photography) */}
      <div style={{ position: "absolute", top: -120, right: -80, width: 420, height: 420, borderRadius: 999,
                    background: "radial-gradient(circle, rgba(78,174,255,.35), transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: -160, left: -60, width: 380, height: 380, borderRadius: 999,
                    background: "radial-gradient(circle, rgba(93,245,255,.18), transparent 70%)" }} />
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "72px 28px 96px", position: "relative" }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 7, font: "700 11px var(--font-ui)",
                       letterSpacing: ".06em", textTransform: "uppercase", color: "#94D2FF",
                       background: "rgba(78,174,255,.12)", border: "1px solid rgba(78,174,255,.25)",
                       padding: "7px 14px", borderRadius: 999 }}>
          <Icon name="shield" size={14} /> Trusted travel consultants since 2009
        </span>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 76, lineHeight: .92, color: "#fff",
                     margin: "22px 0 0", letterSpacing: ".01em", maxWidth: 760 }}>
          Plan Your Perfect Journey
        </h1>
        <p style={{ font: "400 16px/1.6 var(--font-ui)", color: "#CBD5E1", marginTop: 16, maxWidth: 540 }}>
          Flights, hotels, tour packages and visa services — arranged end-to-end by our team. Tell us where you dream of going.
        </p>

        {/* Search panel */}
        <div style={{ background: "#fff", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-lg)",
                      marginTop: 40, padding: 20, maxWidth: 920 }}>
          <div style={{ display: "flex", gap: 8, background: "#F3F4F6", padding: 5, borderRadius: "var(--radius-md)",
                        width: "fit-content", marginBottom: 18 }}>
            {SEARCH_TABS.map((t) => {
              const on = tab === t.label;
              return (
                <button key={t.label} onClick={() => setTab(t.label)}
                  style={{ display: "flex", alignItems: "center", gap: 7, border: "none", cursor: "pointer",
                           background: on ? "#fff" : "transparent", color: on ? "var(--blue-primary)" : "var(--gray-dark)",
                           boxShadow: on ? "var(--shadow-sm)" : "none", font: "700 13px var(--font-ui)",
                           padding: "9px 18px", borderRadius: "var(--radius-sm)", transition: "all .12s" }}>
                  <Icon name={t.icon} size={16} /> {t.label}
                </button>
              );
            })}
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "stretch" }}>
            <Field label="From" value="Dubai, UAE" sub="DXB · Dubai Intl" style={{ flex: 1 }} />
            <Field label={tab === "Visa" ? "Destination Country" : "To"} placeholder="Search city…"
                   value={to} editable onChange={(e) => setTo(e.target.value)} style={{ flex: 1 }} />
            <Field label="Dates" value="25 Mar — 1 Apr" sub="7 nights" style={{ flex: 1 }} />
            <Field label="Travellers" value="2 Adults" sub="Economy" style={{ flex: 1 }} />
            <Button variant="primary" size="lg" onClick={onSearch}
                    style={{ flex: "0 0 auto", alignSelf: "stretch", height: "auto" }}>
              <Icon name="arrowRight" size={18} /> Search
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatBar() {
  const stats = [["500+", "Destinations"], ["120+", "Airlines"], ["10K+", "Hotels"], ["2M+", "Travellers served"]];
  return (
    <div style={{ maxWidth: 1180, margin: "-44px auto 0", padding: "0 28px", position: "relative", zIndex: 2 }}>
      <div style={{ background: "#fff", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-md)",
                    border: "1px solid var(--border)", display: "grid", gridTemplateColumns: "repeat(4,1fr)" }}>
        {stats.map(([n, l], i) => (
          <div key={l} style={{ padding: "26px 24px", textAlign: "center",
                                borderLeft: i ? "1px solid var(--border)" : "none" }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 40, color: "var(--blue-primary)", lineHeight: 1 }}>{n}</div>
            <div style={{ font: "600 13px var(--font-ui)", color: "var(--gray)", marginTop: 6 }}>{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

const PACKAGES = [
  { id: "istanbul", place: "Cappadocia", loc: "Istanbul, Turkey", sub: "7 nights · Hotel + Flights", tag: "TOUR PACKAGE",
    price: "2,850", rating: 4.9, nights: "7 Nights", grad: "linear-gradient(135deg,#0F2E85,#1F73C7 55%,#2EB8D6)" },
  { id: "bali", place: "Bali Escape", loc: "Bali, Indonesia", sub: "5 nights all-inclusive", tag: "SPECIAL OFFER", offer: true,
    price: "1,890", was: "2,400", rating: 4.8, nights: "Limited Seats", grad: "linear-gradient(135deg,#1A4726,#2E7A40 55%,#5CB261)" },
  { id: "georgia", place: "Tbilisi & Kazbegi", loc: "Georgia", sub: "6 nights · Mountains + City", tag: "TOUR PACKAGE",
    price: "2,150", rating: 4.7, nights: "6 Nights", grad: "linear-gradient(135deg,#3A1D5E,#6A3FA0 55%,#A06ED6)" },
  { id: "umrah", place: "Umrah Premium", loc: "Makkah & Madinah", sub: "10 nights · 5★ near Haram", tag: "UMRAH",
    price: "4,200", rating: 5.0, nights: "10 Nights", grad: "linear-gradient(135deg,#0B3B2E,#1E7A5E 55%,#3BB78F)" },
];

function PackageGrid({ onInquire }) {
  return (
    <section style={{ maxWidth: 1180, margin: "72px auto 0", padding: "0 28px" }}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 28 }}>
        <div>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: 44, color: "var(--black)", margin: 0, lineHeight: 1 }}>
            Tour Packages &amp; Offers
          </h2>
          <p style={{ font: "400 14px var(--font-ui)", color: "var(--gray)", marginTop: 8 }}>
            Hand-built itineraries. Hotel and flights included. Subject to availability.
          </p>
        </div>
        <Button variant="outline" size="sm">View all <Icon name="chevronRight" size={15} /></Button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 20 }}>
        {PACKAGES.map((p) => <PackageCard key={p.id} p={p} onInquire={onInquire} />)}
      </div>
    </section>
  );
}

function PackageCard({ p, onInquire }) {
  const [hover, setHover] = useStateHome(false);
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
         style={{ borderRadius: 20, background: p.offer ? "var(--night-850)" : "var(--night-700)",
                  border: p.offer ? "1.5px solid rgba(255,157,46,.3)" : "1px solid rgba(78,174,255,.12)",
                  overflow: "hidden", transition: "transform .15s ease, box-shadow .15s ease",
                  transform: hover ? "translateY(-4px)" : "none",
                  boxShadow: hover ? "0 18px 40px rgba(10,23,46,.45)" : "none", cursor: "pointer" }}
         onClick={() => onInquire(p)}>
      <div style={{ height: 150, background: p.grad, position: "relative", display: "flex",
                    alignItems: "flex-end", padding: 14 }}>
        <span style={{ position: "absolute", top: 14, left: 14, font: "700 10px var(--font-ui)", color: "#fff",
                       background: p.offer ? "linear-gradient(180deg,#FF8C42,#F04545)" : "rgba(255,255,255,.15)",
                       border: p.offer ? "none" : "1px solid rgba(255,255,255,.3)", padding: "5px 10px", borderRadius: p.offer ? 8 : 999 }}>
          {p.offer ? "🔥 " : "✈ "}{p.nights}
        </span>
        <div>
          <div style={{ font: "700 11px var(--font-ui)", color: "rgba(255,255,255,.85)" }}>{p.loc}</div>
          <div style={{ font: "700 13px var(--font-ui)", color: "#fff", marginTop: 4 }}>{p.sub}</div>
        </div>
      </div>
      <div style={{ padding: 16 }}>
        <span style={{ display: "inline-block", whiteSpace: "nowrap", font: "700 9px var(--font-ui)", letterSpacing: ".04em",
                       color: p.offer ? "#1A1A1A" : "#60A5FA", background: p.offer ? "var(--gold-primary)" : "#1E3A8A",
                       padding: "5px 10px", borderRadius: 6 }}>{p.tag}</span>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "#fff", margin: "12px 0 4px", lineHeight: 1 }}>{p.place}</div>
        <div style={{ height: 1, background: "#1E293B", margin: "14px 0" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            {p.was && <span style={{ fontSize: 11, color: "#64748B", textDecoration: "line-through", marginRight: 6 }}>AED {p.was}</span>}
            <div><span style={{ fontSize: 11, color: "#64748B" }}>AED</span> <span style={{ fontFamily: "var(--font-display)", fontSize: 28, color: p.offer ? "var(--gold-primary)" : "#fff", lineHeight: .9 }}>{p.price}</span></div>
            <div style={{ fontSize: 10, color: "#64748B" }}>/ person</div>
          </div>
          <div style={{ textAlign: "right" }}><Stars value={p.rating} /><div style={{ color: "#fff", fontWeight: 700, fontSize: 12, marginTop: 3 }}>{p.rating}</div></div>
        </div>
        <Button variant={p.offer ? "gold" : "primary"} size="sm" full style={{ marginTop: 14 }}
                onClick={(e) => { e.stopPropagation(); onInquire(p); }}>Send Inquiry →</Button>
      </div>
    </div>
  );
}

function ServicesStrip() {
  const svc = [
    { icon: "plane", h: "Flights", d: "120+ airlines, best fares, flexible routing." },
    { icon: "bed", h: "Hotels", d: "Hand-picked stays from 3★ to luxury." },
    { icon: "map", h: "Tour Packages", d: "Complete itineraries, guided or independent." },
    { icon: "passport", h: "Visa Services", d: "Applications, renewals, document checks." },
  ];
  return (
    <section style={{ maxWidth: 1180, margin: "72px auto 0", padding: "0 28px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 20 }}>
        {svc.map((s) => (
          <div key={s.h} style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-xl)",
                                  padding: 24, boxShadow: "var(--shadow-sm)" }}>
            <div style={{ width: 48, height: 48, borderRadius: "var(--radius-md)", background: "var(--blue-surface)",
                          display: "flex", alignItems: "center", justifyContent: "center", color: "var(--blue-primary)" }}>
              <Icon name={s.icon} size={24} />
            </div>
            <h3 style={{ font: "700 16px var(--font-ui)", color: "var(--black)", margin: "16px 0 6px" }}>{s.h}</h3>
            <p style={{ font: "400 13px/1.6 var(--font-ui)", color: "var(--gray)", margin: 0 }}>{s.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

Object.assign(window, { HeroSearch, StatBar, PackageGrid, PackageCard, ServicesStrip, PACKAGES });
