// inquiry.jsx — Inquiry flow: step indicator, summary, form, upload, confirmation
const { useState: useStateInq } = React;

function StepIndicator({ current = 2 }) {
  const steps = ["Select Service", "Your Details", "Documents", "Confirm"];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0, maxWidth: 620 }}>
      {steps.map((s, i) => {
        const n = i + 1, done = n < current, active = n === current;
        return (
          <React.Fragment key={s}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, flex: "0 0 auto" }}>
              <div style={{ width: 38, height: 38, borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center",
                            font: "700 14px var(--font-ui)",
                            background: done || active ? "var(--blue-primary)" : "#fff",
                            color: done || active ? "#fff" : "var(--gray)",
                            border: done || active ? "none" : "1.5px solid var(--border)" }}>
                {done ? <Icon name="check" size={18} color="#fff" strokeWidth={3} /> : n}
              </div>
              <span style={{ font: "600 11px var(--font-ui)", color: active ? "var(--black)" : "var(--gray)", whiteSpace: "nowrap" }}>{s}</span>
            </div>
            {i < steps.length - 1 && (
              <div style={{ flex: 1, height: 2, background: n < current ? "var(--blue-primary)" : "var(--border)", margin: "0 8px", marginBottom: 26 }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function UploadBox() {
  const [file, setFile] = useStateInq(null);
  return (
    <label style={{ display: "block", border: "1.5px dashed var(--gray-300)", borderRadius: "var(--radius-lg)",
                    background: "var(--bg-page)", padding: "26px", textAlign: "center", cursor: "pointer" }}>
      <input type="file" style={{ display: "none" }} onChange={(e) => setFile(e.target.files[0]?.name)} />
      <div style={{ width: 44, height: 44, borderRadius: 999, background: "var(--blue-surface)", display: "flex",
                    alignItems: "center", justifyContent: "center", margin: "0 auto 12px", color: "var(--blue-primary)" }}>
        <Icon name="upload" size={22} />
      </div>
      <div style={{ font: "600 14px var(--font-ui)", color: file ? "var(--blue-deep)" : "var(--gray-dark)" }}>
        {file || "Drop files or click to upload"}
      </div>
      <div style={{ font: "400 12px var(--font-ui)", color: "var(--gray)", marginTop: 4 }}>Passport · visa photo — PDF, JPG, PNG, max 5MB</div>
    </label>
  );
}

function InqInput({ label, placeholder, value, onChange, half }) {
  return (
    <div style={{ flex: half ? 1 : "1 1 100%" }}>
      <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)", marginBottom: 7 }}>{label}</div>
      <input value={value} placeholder={placeholder} onChange={onChange}
             style={{ width: "100%", boxSizing: "border-box", height: 46, padding: "0 14px", borderRadius: "var(--radius-md)",
                      border: "1px solid var(--border)", font: "500 14px var(--font-ui)", color: "var(--black)", outline: "none" }}
             onFocus={(e) => { e.target.style.border = "2px solid var(--blue-primary)"; e.target.style.background = "var(--blue-surface)"; e.target.style.padding = "0 13px"; }}
             onBlur={(e) => { e.target.style.border = "1px solid var(--border)"; e.target.style.background = "#fff"; e.target.style.padding = "0 14px"; }} />
    </div>
  );
}

function InquiryView({ pkg, onSubmit, onBack }) {
  const [f, setF] = useStateInq({ name: "", email: "", phone: "", travellers: "2", notes: "" });
  const up = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div style={{ background: "var(--bg-page)", minHeight: "80vh" }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "26px 28px 64px" }}>
        <button onClick={onBack} style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "transparent",
                 color: "var(--gray-dark)", font: "600 13px var(--font-ui)", cursor: "pointer", marginBottom: 22 }}>
          <Icon name="chevronRight" size={15} style={{ transform: "rotate(180deg)" }} /> Back to results
        </button>
        <div style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-xl)", padding: "26px 28px", marginBottom: 24 }}>
          <StepIndicator current={2} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 24, alignItems: "start" }}>
          {/* Form */}
          <div style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-xl)", padding: 28 }}>
            <h2 style={{ font: "700 20px var(--font-ui)", color: "var(--black)", margin: "0 0 4px" }}>Send your inquiry</h2>
            <p style={{ font: "400 13px var(--font-ui)", color: "var(--gray)", margin: "0 0 24px" }}>Our team replies within a few hours. No payment is taken online.</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
              <InqInput label="Full name" placeholder="As on passport" value={f.name} onChange={up("name")} half />
              <InqInput label="Travellers" placeholder="2 Adults" value={f.travellers} onChange={up("travellers")} half />
              <InqInput label="Email" placeholder="you@email.com" value={f.email} onChange={up("email")} half />
              <InqInput label="Phone / WhatsApp" placeholder="+971…" value={f.phone} onChange={up("phone")} half />
              <div style={{ flex: "1 1 100%" }}>
                <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)", marginBottom: 7 }}>Notes (optional)</div>
                <textarea value={f.notes} onChange={up("notes")} placeholder="Preferred dates, room type, special requests…"
                          style={{ width: "100%", boxSizing: "border-box", minHeight: 84, padding: 14, borderRadius: "var(--radius-md)",
                                   border: "1px solid var(--border)", font: "500 14px/1.5 var(--font-ui)", color: "var(--black)", outline: "none", resize: "vertical" }} />
              </div>
            </div>
            <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase", color: "var(--gray)", margin: "22px 0 10px" }}>Documents</div>
            <UploadBox />
            <Badge tone="gold" dot style={{ marginTop: 18 }}>Visa Required · we’ll guide you</Badge>
          </div>
          {/* Summary */}
          <div style={{ background: "var(--night-700)", borderRadius: "var(--radius-xl)", padding: 24, color: "#fff", position: "sticky", top: 92 }}>
            <div style={{ font: "700 10px var(--font-ui)", letterSpacing: ".06em", textTransform: "uppercase", color: "#94D2FF" }}>Inquiry Summary</div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 28, margin: "12px 0 4px", lineHeight: 1 }}>{pkg?.place || "Istanbul Package"}</div>
            <div style={{ font: "500 13px var(--font-ui)", color: "#94A3B8" }}>{pkg?.loc || "Istanbul, Turkey"}</div>
            <div style={{ height: 1, background: "#1E293B", margin: "18px 0" }} />
            {[["Travellers", f.travellers || "2"], ["Service", "Package"], ["Hotel + Flights", "Included"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 12, font: "500 13px var(--font-ui)", color: "#CBD5E1", padding: "6px 0" }}>
                <span style={{ color: "#94A3B8", whiteSpace: "nowrap" }}>{k}</span><span style={{ fontWeight: 700, color: "#fff", whiteSpace: "nowrap" }}>{v}</span>
              </div>
            ))}
            <div style={{ height: 1, background: "#1E293B", margin: "18px 0" }} />
            <div style={{ font: "500 12px var(--font-ui)", color: "#94A3B8" }}>Estimated price</div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 4 }}>
              <span style={{ fontSize: 13, color: "#64748B" }}>from AED</span>
              <span style={{ fontFamily: "var(--font-display)", fontSize: 34, color: "#fff" }}>{pkg?.price || "2,850"}</span>
              <span style={{ fontSize: 12, color: "#64748B" }}>/ person</span>
            </div>
            <Button variant="primary" size="lg" full style={{ marginTop: 20 }} onClick={onSubmit}>Send Inquiry →</Button>
            <div style={{ display: "flex", alignItems: "center", gap: 7, justifyContent: "center", marginTop: 14, font: "500 11px var(--font-ui)", color: "#64748B" }}>
              <Icon name="shield" size={13} color="#64748B" /> No payment taken · consultant will confirm
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfirmationView({ pkg, onHome }) {
  return (
    <div style={{ background: "var(--bg-page)", minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "64px 28px" }}>
      <div style={{ background: "#fff", border: "1px solid var(--border)", borderRadius: "var(--radius-2xl)", padding: "48px 44px",
                    maxWidth: 520, textAlign: "center", boxShadow: "var(--shadow-lg)" }}>
        <div style={{ width: 72, height: 72, borderRadius: 999, background: "var(--success-surface)", display: "flex",
                      alignItems: "center", justifyContent: "center", margin: "0 auto 22px" }}>
          <Icon name="check" size={38} color="var(--success)" strokeWidth={3} />
        </div>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 40, color: "var(--black)", margin: "0 0 10px", lineHeight: 1 }}>Inquiry Received</h2>
        <p style={{ font: "400 14px/1.6 var(--font-ui)", color: "var(--gray-dark)", margin: "0 0 8px" }}>
          Thank you — our team will reach out about <strong style={{ color: "var(--black)" }}>{pkg?.place || "your trip"}</strong> within a few hours by email and WhatsApp.
        </p>
        <p style={{ font: "400 13px var(--font-ui)", color: "var(--gray)", margin: "0 0 28px" }}>Reference <strong>SKY-2026-4471</strong></p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <Button variant="outline" size="md" onClick={onHome}>Back to home</Button>
          <Button variant="primary" size="md"><Icon name="mail" size={16} /> View confirmation</Button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { StepIndicator, InquiryView, ConfirmationView });
