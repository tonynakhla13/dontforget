// primitives.jsx — Sky Sham brand primitives
const { useState } = React;

// Brand lockup — official Sky Sham · Travel & Tours mark (transparent PNG,
// dark-navy lettering, so on dark surfaces pass chip to sit it on a white safe-area)
function Logo({ height = 50, chip = false }) {
  const img = <img src="../../assets/sky-sham-logo.png" alt="Sky Sham Travel & Tours"
                   style={{ height, width: height, objectFit: "contain", display: "block" }} />;
  if (chip) {
    return <div style={{ background: "#fff", borderRadius: "var(--radius-md)", padding: 6,
                         display: "inline-flex", boxShadow: "0 4px 14px rgba(0,0,0,.2)" }}>{img}</div>;
  }
  return img;
}

const btnBase = {
  border: "none", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700,
  display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
  borderRadius: "var(--radius-lg)", transition: "transform .12s ease, box-shadow .15s ease, filter .15s ease",
  whiteSpace: "nowrap",
};
const btnSizes = {
  sm: { height: 36, padding: "0 16px", fontSize: 12, borderRadius: "var(--radius-md)" },
  md: { height: 44, padding: "0 22px", fontSize: 13 },
  lg: { height: 52, padding: "0 28px", fontSize: 15 },
};
function Button({ children, variant = "primary", size = "md", onClick, style = {}, full = false }) {
  const [hover, setHover] = useState(false);
  const variants = {
    primary: { background: "var(--grad-blue)", color: "#fff",
               boxShadow: hover ? "var(--shadow-blue)" : "var(--shadow-sm)" },
    gold:    { background: "var(--grad-gold)", color: "#1A1A1A",
               boxShadow: hover ? "var(--shadow-gold)" : "var(--shadow-sm)" },
    secondary:{ background: "#fff", color: "var(--blue-deep)", border: "1.5px solid var(--blue-primary)",
                boxShadow: hover ? "var(--shadow-md)" : "none" },
    outline: { background: "transparent", color: "var(--blue-primary)", border: "1.5px solid var(--blue-primary)",
               background: hover ? "var(--blue-surface)" : "transparent" },
    ghost:   { background: hover ? "#F3F4F6" : "transparent", color: "var(--gray-dark)", border: "1.5px solid var(--border)" },
  };
  return (
    <button style={{ ...btnBase, ...btnSizes[size], ...variants[variant],
                     width: full ? "100%" : "auto",
                     transform: hover ? "translateY(-1px)" : "none", ...style }}
            onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      {children}
    </button>
  );
}

function Badge({ children, tone = "neutral", dot = false, style = {} }) {
  const tones = {
    success: { bg: "var(--success-surface)", fg: "#15803D", d: "var(--success)" },
    warning: { bg: "var(--warning-surface)", fg: "#92400E", d: "var(--warning)" },
    danger:  { bg: "var(--danger-surface)", fg: "#991B1B", d: "var(--danger)" },
    info:    { bg: "var(--blue-secondary)", fg: "#1A6FA0", d: "var(--info)" },
    gold:    { bg: "var(--gold-light)", fg: "#92400E", d: "var(--gold-deep)" },
    brand:   { bg: "var(--gold-primary)", fg: "#1A1A1A", d: "var(--gold-deep)" },
    neutral: { bg: "#F3F4F6", fg: "var(--gray-dark)", d: "var(--gray)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 24, padding: "0 12px",
                   borderRadius: 999, background: t.bg, color: t.fg,
                   font: "700 10px var(--font-ui)", letterSpacing: ".02em", ...style }}>
      {dot && <span style={{ width: 8, height: 8, borderRadius: 999, background: t.d }} />}
      {children}
    </span>
  );
}

// Search field used in hero + forms
function Field({ label, value, sub, placeholder, focus = false, onClick, onChange, editable = false, style = {} }) {
  const [f, setF] = useState(false);
  const active = focus || f;
  return (
    <div onClick={onClick} onFocus={() => setF(true)} onBlur={() => setF(false)}
         style={{ borderRadius: "var(--radius-md)", background: active ? "var(--blue-surface)" : "#fff",
                  border: active ? "2px solid var(--blue-primary)" : "1px solid var(--border)",
                  padding: active ? "11px 15px" : "12px 16px", cursor: onClick ? "pointer" : "text",
                  transition: "all .12s ease", ...style }}>
      <div style={{ font: "700 9px var(--font-ui)", letterSpacing: ".05em", textTransform: "uppercase",
                    color: active ? "var(--blue-primary)" : "var(--gray)" }}>{label}</div>
      {editable ? (
        <input value={value} placeholder={placeholder} onChange={onChange} onFocus={() => setF(true)} onBlur={() => setF(false)}
               style={{ border: "none", outline: "none", background: "transparent", marginTop: 6,
                        font: "700 14px var(--font-ui)", color: "var(--black)", width: "100%" }} />
      ) : value ? (
        <>
          <div style={{ font: "700 14px var(--font-ui)", color: "var(--black)", marginTop: 6 }}>{value}</div>
          {sub && <div style={{ fontSize: 11, color: "var(--gray)", marginTop: 3 }}>{sub}</div>}
        </>
      ) : (
        <div style={{ fontSize: 14, color: "var(--gray-300)", marginTop: 6 }}>{placeholder}</div>
      )}
    </div>
  );
}

Object.assign(window, { Logo, Button, Badge, Field });
