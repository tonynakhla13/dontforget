# Sky Sham — Design System

**Sky Sham** (full lockup: *SKY SHAM · Travel & Tours*; Arabic heritage name *Sama Al Sham*) is an **inquiry-based travel platform** based in the UAE. It helps individuals, families and B2B partners plan complete journeys — **flights, hotels, tour packages, Umrah and visa services** — across the Middle East and beyond (Istanbul, Bali, Georgia, Turkey, the GCC). Prices are quoted in **AED**.

The defining product behaviour: **Sky Sham never takes payment online.** Every primary action is an *inquiry* — "Send Inquiry", "Inquire →", "Request a Quote". Buttons that look like checkout CTAs elsewhere are, here, the start of a consultant-led conversation. This shapes the entire UI: search → results → inquiry form → document upload → confirmation.

This repository is a **design system**: brand foundations (color, type, spacing, radius, elevation), component specs (buttons, inputs, badges, alerts, cards), real assets (the logo), and a high-fidelity **UI kit** that recreates the product so future designs stay on-brand.

---

## Sources

- **Figma — "desgin system.fig"** (mounted, read-only): the canonical source. Page `Page-1` holds 13 frames:
  `00 Variable System · 01 Colors · 02 Typography · 03 Spacing & Radius · 04 Border Radius · 05 Buttons · 06 Forms & Inputs · 07 Badges & Tags · 08 Alerts · 09 Cards · 10 Accent Color Suggestions · 11 Atoms from Wireframes · Design System banner`.
  Every token, component and the product wireframe atoms (search tabs, flight result row, filter panel, hotel card, step indicator, upload box) were lifted from these frames.
- **Figma — "skyshame hero.fig"**: referenced but the hero/3D-imagery frames were **not present in the mount** — see Caveats.
- **`uploads/1-1 Sama Al Sham logo.svg`**: the official brand mark (copied to `assets/sky-sham-logo.svg`).

> The reader is not assumed to have Figma access; everything needed has been reconstructed into the files below.

---

## CONTENT FUNDAMENTALS

**Voice.** Warm, knowledgeable, concierge-like — a trusted travel consultant, not a discount aggregator. Confident but never pushy. The platform *advises and arranges*; it doesn't transact.

**Person.** Speaks to **"you"** ("Plan Your Perfect Journey", "Select your travel dates and destination"). Describes itself as **"we" / "our team"** ("We craft complete travel experiences…", "Contact our team for pricing"). This we↔you framing reinforces the human, consultant-led model.

**Casing.**
- **Display / hero** copy in **Bebas Neue** is naturally all-caps by typeface (e.g. *PLAN YOUR PERFECT JOURNEY*), set in Title Case in source.
- **Headings & body** in Montserrat use **sentence-style Title Case** for headings, sentence case for body.
- **Labels, tags, micro-CTAs** are **UPPERCASE** with letter-spacing (`TOUR PACKAGE`, `VISA REQUIRED`, `NEW OFFER`, `B2B`, `7 NIGHTS`).

**Vocabulary.** Travel-domain and inquiry-first: *Send Inquiry, Inquire, View Packages, Tour Package, Visa Service, Umrah, Limited Seats, Visa Required, 7 Nights, Best price today, Estimated Price, Inquiry Summary*. Currency is always **AED**, often with "/ person" or "/ night". Ratings shown as ★ + number + "(N reviews)".

**Tone examples (verbatim from source):**
- "We craft complete travel experiences for individuals, families and B2B clients."
- "Hotel and flights included. Subject to availability. Contact our team for pricing."
- "Your Turkey visa has been approved. Check email." (success alert)
- "Only 3 spots left for this departure date." (warning alert)
- "Your passport expires in less than 6 months." (danger alert)

**Emoji.** Used **sparingly and functionally** inside the product — small wayfinding glyphs on tabs and chips (🏨 Hotels, 🗺 Trips, 📋 Visa, ✈ 7 Nights, 🔍 search, 🔥 LIMITED SEATS). They are accents, never decoration in prose. The spec sheets themselves use a few section icons (📐 ⬛ 🔤 ✨). Prefer real iconography over emoji in production surfaces.

---

## VISUAL FOUNDATIONS

**Overall vibe.** Clean, airy, modern-travel. Two complementary moods coexist:
1. **Light product UI** — `#F9FAFB` page, white cards, generous whitespace, blue accents. Used for search, results, forms, marketing.
2. **Premium "night" surfaces** — deep navy (`#0A172E → #111827 → #1E293B`) with blue/gold accents and a blue→cyan gradient hairline. Used for hero bands, the design-system spec sheets, and the flagship **tour-package cards**.

**Color.** Brand blue `#4EAEFF` is the hero — links, active states, primary CTAs (as a `#4FABFF→#1A73DB` vertical gradient). A **gold/yellow** family (`#FFD166 → #FFAD0D`) is the secondary accent reserved for **offers, highlights and special-offer CTAs**. Neutrals are cool grays (`#1A1A1A / #595A5C / #7F8184 / #E5E7EB`). Semantic colors: green success, amber warning, red danger, blue info — each with a soft tinted surface for badges/alerts.

**Type.** Two families only. **Bebas Neue** for display moments (64 hero / 44 section / 32 card header) — tall, condensed, confident. **Montserrat** for everything else (H1 24·700, H2 18·700, H3 15·600, body 14/12·400, labels 10·700 uppercase). Generous line-height on body (~1.6); display is tight (~0.92–1.0).

**Spacing.** Strict **4px base grid**: 4/8/12/16/24/32/48/64. Card padding ~16, related-element gaps ~24, section breaks ~48, page padding ~64.

**Radius.** sm 4 (micro tags) · md 8 (buttons/inputs/small cards) · lg 12 (cards/dropdowns) · xl 16 (modals/panels) · 2xl 20–24 (hero/package cards) · pill 999 (status chips, avatars, badges). Package/hero cards use a notably large **20px** radius.

**Backgrounds & imagery.** The brand is built around **real 3D / photographic destination imagery** (per brief). In source these are stand-in **diagonal gradient blocks** inside a 20px-radius image area (blue `#0F2E85→#1F73C7→#2EB8D6`, green offer `#1A4726→#2E7A40→#5CB261`, etc.) with an overlaid pill chip and white destination text bottom-left. **In production, replace gradient blocks with real photos** — warm, vivid, aspirational destination shots. Use `image-slot` placeholders in mocks. No hand-drawn illustration; no repeating patterns.

**Elevation / shadows.** Soft, low, cool-toned drop shadows on light cards (`0 4px 12px rgba(16,24,40,.08)`). CTAs can lift with a colored glow (blue `rgba(78,174,255,.30)`, gold `rgba(255,173,13,.30)`). On night surfaces, depth comes from a `1px solid rgba(78,174,255,.15)` hairline border + a thin blue→cyan gradient accent bar, rather than heavy shadow.

**Borders.** Hairline `1px #E5E7EB` on light; `rgba(78,174,255,.12–.25)` on dark cards. Focused inputs get a **2px `#4EAEFF`** border over a `#F5FEFF` fill. Offer cards use a `1.5px rgba(255,209,102,.25)` gold hairline.

**Animation.** Restrained and functional — short ease-out fades/translates (~150–250ms) on hover and entrance; no bounces, no infinite decorative loops. Honour `prefers-reduced-motion`.

**Hover states.** Buttons darken/deepen the gradient and lift slightly with a colored shadow; links and ghosts brighten toward `#4EAEFF` / fill with `#DBFBFF`; cards raise shadow + nudge up 2–4px.

**Press states.** Scale down subtly (~0.98) and/or deepen color (toward `#1A73DB`).

**Transparency & blur.** Used lightly — translucent white chips over imagery (`rgba(255,255,255,.15)` + `rgba(255,255,255,.3)` border) sit on the gradient image areas; overlay scrims and modal backdrops use blur sparingly.

**Cards.** Light variant: white, 12–16px radius, hairline border, soft shadow. Flagship **package card**: 260×420, 20px radius, photo/gradient image area (200px) with chip + destination, dark-navy body, divider, AED price + rating, full-width inquiry CTA. Hotel card: horizontal, image left, details middle, price + Inquire right.

**Layout rules.** Centered max-width content with 64px gutters; sticky top nav; multi-step flows use a numbered **step indicator** (Select Service → Documents → Confirm). Breadcrumbs on deep pages. Filter panel as a left rail on results.

---

## ICONOGRAPHY

There is **no bespoke icon font or SVG icon set** in the source files — the wireframes represent icons as placeholder squares and a handful of **emoji glyphs** used functionally (🏨 🗺 📋 ✈ 🔍 🔥 ★). The brand mark itself is the only true vector asset.

**Recommendation (and what this system uses):** adopt **[Lucide](https://lucide.dev)** as the icon set — its thin, rounded `~1.5px` stroke and travel-friendly glyph coverage (plane, hotel/bed, map, file-text, search, calendar, star, check) match the clean Montserrat UI. Loaded from CDN in the UI kit. **This is a substitution and should be confirmed** — if Sky Sham has an official icon set, swap it in. Stars (★) for ratings and the brand's existing emoji wayfinding glyphs may be retained where they already appear.

Assets in `assets/`:
- `sky-sham-logo.png` — **official primary logo** (1080×1080, transparent): the "SKY" wordmark with a cyan roundel + white airplane for the O, over "SKY SHAM / Travel & Tours" in gradient navy. Use on light surfaces; on dark, place on a white safe-area chip (dark-navy lettering). **This is the canonical mark.**
- `sky-sham-logo.svg` — earlier *Sama Al Sham · Tourism Consultants* vector mark. ⚠️ Renders with a black-box bug in Chromium (vectorized raster) — kept for reference only; prefer the PNG.

---

## INDEX — what's in this system

| Path | What it is |
|---|---|
| `README.md` | This file — brand context, content & visual foundations, iconography, index. |
| `colors_and_type.css` | All design tokens as CSS custom properties + semantic type classes. Import this everywhere. |
| `SKILL.md` | Agent Skill manifest (for use in Claude Code). |
| `assets/` | Brand logo and any shared imagery. |
| `preview/` | Small HTML spec cards rendered in the Design System tab (colors, type, spacing, radius, buttons, badges, alerts, cards). |
| `ui_kits/web-platform/` | High-fidelity, click-through recreation of the Sky Sham travel platform (search → results → inquiry). `index.html` + JSX components. |

**Fonts:** Bebas Neue + Montserrat are both Google Fonts, loaded via CDN in `colors_and_type.css` — no local font files required, no substitution.
