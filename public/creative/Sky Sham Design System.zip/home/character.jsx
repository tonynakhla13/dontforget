// character.jsx — Skysham "sales character" that slides into the screen at certain sections.
// The wireframe marks recurring "SALES CHARACTER POP-UP ZONE"s; this realises them as an
// animated mascot that flies/slides in, shows a speech bubble, then can be dismissed.
const { useState: useCharState, useEffect: useCharEffect, useRef: useCharRef } = React;

const SCRIPTS = {
  hero:   { side: "right", text: "Hi! I'm Sami ✈️ Tell me where you'd love to go and I'll find the best deal for you!" },
  deals:  { side: "left",  text: "🔥 These fares change every hour — want me to lock one in before it's gone?" },
  trips:  { side: "right", text: "Not sure which package? I can match a trip to your style in 30 seconds 😊" },
  reward: { side: "left",  text: "You're only 500 points away from Gold tier! Book now to get there 🏆" },
  exit:   { side: "right", text: "Wait! Every booking is 100% secure and free to cancel. Need a hand? 😊" },
};

function SpeechBubble({ side, children, onClose }) {
  return (
    <div style={{ position: "relative", maxWidth: 290, background: "#fff", borderRadius: 18,
                  padding: "16px 18px", boxShadow: "0 18px 44px rgba(10,23,48,.22)",
                  border: "1px solid #E9EFF6" }}>
      <button onClick={onClose} aria-label="Dismiss" style={{ position: "absolute", top: 8, right: 8, width: 22, height: 22,
               border: "none", background: "#F1F5F9", borderRadius: 999, cursor: "pointer", color: "#8A93A6",
               display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>×</button>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: "#22C55E" }} />
        <span style={{ font: "700 12px var(--font-ui)", color: "#1270C4" }}>Sami · Travel Assistant</span>
      </div>
      <div style={{ font: "500 14px/1.5 var(--font-ui)", color: "#0A1730", paddingRight: 8 }}>{children}</div>
      <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
        <button style={{ flex: 1, border: "none", cursor: "pointer", borderRadius: 10, padding: "9px 0",
                         background: "linear-gradient(180deg,#1461FB,#1270C4)", color: "#fff", font: "700 13px var(--font-ui)" }}>Chat now</button>
        <button onClick={onClose} style={{ border: "1px solid #E1E8F0", background: "#fff", cursor: "pointer",
                 borderRadius: 10, padding: "9px 14px", color: "#6B7488", font: "600 13px var(--font-ui)" }}>Later</button>
      </div>
      {/* tail */}
      <div style={{ position: "absolute", bottom: 26, [side === "right" ? "right" : "left"]: -9,
                    width: 18, height: 18, background: "#fff", transform: "rotate(45deg)",
                    borderRight: side === "right" ? "1px solid #E9EFF6" : "none",
                    borderTop: side === "right" ? "none" : "1px solid #E9EFF6",
                    borderBottom: side === "right" ? "1px solid #E9EFF6" : "none",
                    borderLeft: side === "right" ? "none" : "1px solid #E9EFF6" }} />
    </div>
  );
}

function Mascot({ id }) {
  return (
    <div style={{ position: "relative", width: 150, height: 180, flex: "0 0 auto" }}>
      <image-slot id={id} shape="rounded" radius="20" placeholder="Drop 3D character PNG"
        style={{ display: "block", width: 150, height: 180,
                 background: "radial-gradient(120px 150px at 50% 40%, #DCEBFB, #BcD4F0 70%, transparent)",
                 color: "#6E8AAE", font: "600 11px var(--font-ui)", textAlign: "center" }}></image-slot>
      {/* little floating ring under the mascot */}
      <div style={{ position: "absolute", bottom: 4, left: "50%", transform: "translateX(-50%)",
                    width: 96, height: 18, borderRadius: 999, background: "rgba(18,112,196,.18)", filter: "blur(5px)" }} />
    </div>
  );
}

// A single character instance bound to a section id; slides in when that section scrolls into view.
function Character({ scriptKey, anchorId }) {
  const s = SCRIPTS[scriptKey];
  const [shown, setShown] = useCharState(false);
  const [dismissed, setDismissed] = useCharState(false);
  useCharEffect(() => {
    const el = document.querySelector(`[data-char="${anchorId}"]`);
    if (!el) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) setShown(true); });
    }, { threshold: 0.35 });
    io.observe(el);
    return () => io.disconnect();
  }, [anchorId]);

  if (dismissed) return null;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const off = s.side === "right" ? "translateX(130%)" : "translateX(-130%)";
  return (
    <div style={{ position: "fixed", bottom: 28, [s.side]: 28, zIndex: 60,
                  display: "flex", flexDirection: s.side === "right" ? "row" : "row-reverse",
                  alignItems: "flex-end", gap: 8, pointerEvents: shown ? "auto" : "none",
                  transform: shown || reduce ? "translateX(0)" : off,
                  opacity: shown || reduce ? 1 : 0,
                  transition: "transform .6s cubic-bezier(.22,1,.36,1), opacity .5s ease" }}>
      <div style={{ animation: shown ? "charFloat 3.4s ease-in-out infinite" : "none" }}>
        <Mascot id={`char-${scriptKey}`} />
      </div>
      <div style={{ marginBottom: 28 }}>
        <SpeechBubble side={s.side} onClose={() => setDismissed(true)}>{s.text}</SpeechBubble>
      </div>
    </div>
  );
}

// Renders all section-anchored characters; only one visible at a time (latest-triggered wins).
function CharacterLayer() {
  const order = [["hero", "load"], ["deals", "deals"], ["trips", "trips"], ["reward", "reward"], ["exit", "exit"]];
  const [activeIdx, setActiveIdx] = useCharState(0);
  useCharEffect(() => {
    const observers = [];
    order.forEach(([key, anchor], idx) => {
      const el = document.querySelector(`[data-char="${anchor}"]`);
      if (!el) return;
      const io = new IntersectionObserver((entries) => {
        entries.forEach((e) => { if (e.isIntersecting) setActiveIdx(idx); });
      }, { threshold: 0.4 });
      io.observe(el); observers.push(io);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);
  const [key] = order[activeIdx];
  const s = SCRIPTS[key];
  const [dismissed, setDismissed] = useCharState({});
  if (dismissed[key]) return null;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return (
    <div style={{ position: "fixed", bottom: 28, [s.side]: 28, zIndex: 60,
                  display: "flex", flexDirection: s.side === "right" ? "row" : "row-reverse",
                  alignItems: "flex-end", gap: 8,
                  animation: reduce ? "none" : "charSlideIn .6s cubic-bezier(.22,1,.36,1)" }}
         key={key}>
      <div style={{ animation: reduce ? "none" : "charFloat 3.4s ease-in-out infinite" }}>
        <Mascot id={`char-${key}`} />
      </div>
      <div style={{ marginBottom: 28 }}>
        <SpeechBubble side={s.side} onClose={() => setDismissed({ ...dismissed, [key]: true })}>{s.text}</SpeechBubble>
      </div>
    </div>
  );
}

Object.assign(window, { CharacterLayer, Character });
