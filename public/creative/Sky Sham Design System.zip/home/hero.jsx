// hero.jsx — pixel-faithful Skysham hero (from skyshame hero.fig) + boarding-pass search form
const { useState: useHeroState } = React;

const HERO = {
  blue: "#1270C4", blue2: "#1461FB", navy: "#0A1730", ink: "#0E1430", line: "#14629F",
};

function HeroNav() {
  const links = ["Home", "About Us", "Destination", "Reviews", "Blog"];
  const [active, setActive] = useHeroState("Home");
  return (
    <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "26px 56px", position: "relative", zIndex: 5 }}>
      <img src="assets/sky-sham-logo.png" alt="Sky Sham" style={{ height: 60, width: 60, objectFit: "contain" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,.55)",
                    border: "1px solid rgba(255,255,255,.7)", borderRadius: 999, padding: 6, backdropFilter: "blur(6px)" }}>
        {links.map((l) => {
          const on = active === l;
          return (
            <button key={l} onClick={() => setActive(l)}
              style={{ border: "none", cursor: "pointer", font: "600 17px var(--font-ui)", padding: "12px 26px",
                       borderRadius: 999, background: on ? "#fff" : "transparent",
                       color: on ? HERO.navy : "#5A6478", boxShadow: on ? "0 4px 14px rgba(10,23,48,.12)" : "none" }}>{l}</button>
          );
        })}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <button style={iconBtn}><Icon name="search" size={20} color={HERO.navy} /></button>
        <button style={iconBtn}><Icon name="users" size={20} color={HERO.navy} /></button>
        <button style={{ ...iconBtn, background: "#fff", font: "700 13px var(--font-ui)", color: HERO.navy, width: 44 }}>EN</button>
        <button style={{ border: "none", cursor: "pointer", borderRadius: 999, padding: "14px 30px",
                         background: `linear-gradient(180deg, ${HERO.blue2}, ${HERO.blue})`, color: "#fff",
                         font: "700 16px var(--font-ui)", letterSpacing: ".02em", boxShadow: "0 10px 24px rgba(18,112,196,.4)" }}>
          BOOK A TRIP
        </button>
      </div>
    </nav>
  );
}
const iconBtn = { width: 40, height: 40, borderRadius: 999, border: "none", background: "transparent",
                  display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" };

// search icon isn't in our lucide set as "search" path; add a tiny inline fallback
function SearchGlyph({ size = 20, color }) {
  return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>);
}

function TicketTab({ icon, label, active, onClick }) {
  return (
    <button onClick={onClick} style={{ border: "none", background: "transparent", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 12, padding: "8px 4px", position: "relative" }}>
      <Icon name={icon} size={26} color={active ? HERO.blue : "#8A93A6"} />
      <span style={{ font: "700 17px var(--font-ui)", color: active ? HERO.line : "#8A93A6" }}>{label}</span>
      {active && <span style={{ position: "absolute", left: 0, right: 0, bottom: -14, height: 3, borderRadius: 3, background: HERO.blue }} />}
    </button>
  );
}

function TripField({ label, code, place }) {
  return (
    <div style={{ flex: 1, background: "#F6FAFF", borderRadius: 14, padding: "14px 20px", minWidth: 0 }}>
      <div style={{ font: "600 11px var(--font-ui)", letterSpacing: ".08em", textTransform: "uppercase", color: "#9AA3B5" }}>{label}</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginTop: 8 }}>
        <span style={{ width: 7, height: 7, borderRadius: 999, background: HERO.blue, alignSelf: "center" }} />
        <span style={{ font: "700 22px var(--font-ui)", color: HERO.navy }}>{code}</span>
        <span style={{ font: "500 14px var(--font-ui)", color: "#9AA3B5", whiteSpace: "nowrap" }}>· {place}</span>
      </div>
    </div>
  );
}

function MiniField({ label, value, chevron }) {
  return (
    <div style={{ flex: 1, background: "#F6FAFF", borderRadius: 14, padding: "14px 18px", display: "flex",
                  alignItems: "center", gap: 12, minWidth: 0 }}>
      <span style={{ width: 26, height: 26, borderRadius: 7, background: HERO.blue, flex: "0 0 auto" }} />
      <div style={{ minWidth: 0 }}>
        <div style={{ font: "600 11px var(--font-ui)", letterSpacing: ".06em", color: "#9AA3B5" }}>{label}</div>
        <div style={{ font: "700 15px var(--font-ui)", color: HERO.navy, marginTop: 3, whiteSpace: "nowrap" }}>{value}</div>
      </div>
      {chevron && <Icon name="chevronRight" size={16} color="#9AA3B5" style={{ marginLeft: "auto" }} />}
    </div>
  );
}

function TicketForm() {
  const tabs = [["plane", "Flights"], ["bed", "Hotels"], ["passport", "Visa"], ["mapPin", "Trips"]];
  const [tab, setTab] = useHeroState("Flights");
  const [trip, setTrip] = useHeroState("One Way");
  return (
    <div style={{ position: "relative", maxWidth: 1500, margin: "0 auto", padding: "0 40px" }}>
      <div style={{ position: "relative", background: "#fff", borderRadius: 26,
                    boxShadow: "0 30px 70px rgba(10,23,48,.28)", display: "flex", overflow: "hidden" }}>
        {/* left perforation rail with plane + notches */}
        <div style={{ position: "relative", flex: "0 0 116px", borderRight: "2px dashed #C9D2DF",
                      display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="plane" size={40} color="#C2CBD8" style={{ transform: "rotate(-45deg)" }} />
        </div>
        <span style={notch("left", "top")} /><span style={notch("left", "bottom")} />

        {/* main content */}
        <div style={{ flex: 1, padding: "30px 34px 26px" }}>
          <div style={{ display: "flex", gap: 56, borderBottom: "1px solid #EEF2F7", paddingBottom: 16, marginBottom: 22 }}>
            {tabs.map(([ic, lb]) => <TicketTab key={lb} icon={ic} label={lb} active={tab === lb} onClick={() => setTab(lb)} />)}
          </div>
          <div style={{ display: "flex", gap: 10, marginBottom: 18 }}>
            {["One Way", "Round Trip", "Multi-city"].map((t) => {
              const on = trip === t;
              return <button key={t} onClick={() => setTrip(t)}
                style={{ border: "none", cursor: "pointer", borderRadius: 999, padding: "11px 26px", font: "600 14px var(--font-ui)",
                         background: on ? `linear-gradient(180deg, ${HERO.blue2}, ${HERO.blue})` : "transparent",
                         color: on ? "#fff" : "#8A93A6", boxShadow: on ? "0 6px 16px rgba(18,112,196,.35)" : "none" }}>{t}</button>;
            })}
          </div>
          <div style={{ display: "flex", gap: 14, alignItems: "stretch" }}>
            <div style={{ flex: "2 1 0", display: "flex", gap: 0, alignItems: "center", position: "relative" }}>
              <TripField label="From:" code="DXB" place="Dubai, UAE" />
              <button style={{ flex: "0 0 auto", margin: "0 -16px", zIndex: 2, width: 48, height: 48, borderRadius: 999,
                               border: "4px solid #fff", cursor: "pointer", color: "#fff",
                               background: `linear-gradient(180deg, ${HERO.blue2}, ${HERO.blue})`, display: "flex",
                               alignItems: "center", justifyContent: "center", boxShadow: "0 6px 16px rgba(18,112,196,.4)" }}>
                <Icon name="sliders" size={18} color="#fff" style={{ transform: "rotate(90deg)" }} />
              </button>
              <TripField label="To:" code="CDG" place="Paris, France" />
            </div>
            <MiniField label="Departure" value="06 Oct 2025" chevron />
            <MiniField label="Passengers" value="2 Adults" />
            <MiniField label="Class" value="Economy" />
            <button style={{ flex: "0 0 auto", border: "none", cursor: "pointer", borderRadius: 14, padding: "0 30px",
                             background: `linear-gradient(180deg, ${HERO.blue2}, ${HERO.blue})`, color: "#fff",
                             font: "700 17px var(--font-ui)", display: "flex", alignItems: "center", gap: 12,
                             boxShadow: "0 10px 24px rgba(18,112,196,.4)" }}>
              Search Flights <Icon name="arrowRight" size={20} color="#fff" />
            </button>
          </div>
          <div style={{ display: "flex", gap: 28, marginTop: 18, paddingLeft: 4 }}>
            {[["shield", "Best Prices Guaranteed"], ["clock", "24/7 Customer Support"], ["globe", "Secure Booking"]].map(([ic, t], i) => (
              <div key={t} style={{ display: "flex", alignItems: "center", gap: 8, font: "500 13px var(--font-ui)", color: "#6B7488",
                                    borderLeft: i ? "1px solid #E6EBF2" : "none", paddingLeft: i ? 28 : 0 }}>
                <Icon name={ic} size={15} color={HERO.blue} /> {t}
              </div>
            ))}
          </div>
        </div>

        {/* right barcode rail */}
        <div style={{ position: "relative", flex: "0 0 120px", borderLeft: "2px dashed #C9D2DF",
                      display: "flex", alignItems: "center", justifyContent: "center" }}>
          <img src="assets/ticket-barcode.png" alt="" style={{ height: 130, transform: "rotate(90deg)", opacity: .85 }} />
        </div>
        <span style={notch("right", "top")} /><span style={notch("right", "bottom")} />
      </div>
    </div>
  );
}
function notch(side, vert) {
  return { position: "absolute", width: 30, height: 30, borderRadius: 999, background: "var(--ss-hero-under, #EAF4FB)",
           [side]: 100, [vert]: -15, transform: "translateX(" + (side === "left" ? "-50%" : "50%") + ")",
           [side === "left" ? "left" : "right"]: 102 };
}

function Hero() {
  return (
    <header style={{ position: "relative", overflow: "hidden",
                     background: "linear-gradient(180deg,#EAF4FF 0%,#F4FAFF 42%,#E9F6FF 70%)" }}>
      {/* faint mountain photo */}
      <div style={{ position: "absolute", inset: 0, backgroundImage: "url(assets/hero-bg.png)", backgroundSize: "cover",
                    backgroundPosition: "center 30%", opacity: .28, maskImage: "linear-gradient(180deg,#000 0%,transparent 78%)",
                    WebkitMaskImage: "linear-gradient(180deg,#000 0%,transparent 78%)" }} />
      {/* flying SKY plane */}
      <img src="assets/hero-plane.png" alt="" className="hero-plane"
           style={{ position: "absolute", right: "4%", top: 150, width: 620, transform: "rotate(-6deg)",
                    filter: "drop-shadow(0 30px 50px rgba(10,23,48,.22))", pointerEvents: "none" }} />
      <div style={{ position: "relative", zIndex: 2 }}>
        <HeroNav />
        <div style={{ maxWidth: 1500, margin: "0 auto", padding: "60px 56px 0" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 22 }}>
            <Icon name="plane" size={26} color={HERO.blue} />
            <span style={{ font: "700 22px var(--font-ui)", letterSpacing: ".14em", color: HERO.blue }}>YOUR JOURNEY, OUR PASSION</span>
          </div>
          <h1 style={{ font: "800 92px/0.98 var(--font-ui)", color: HERO.navy, margin: 0, letterSpacing: "-.01em", maxWidth: 900 }}>
            Explore the world<br />with <span style={{ position: "relative", whiteSpace: "nowrap" }}>Skysham
              <img src="assets/brush-underline.svg" alt="" style={{ position: "absolute", left: 0, right: 0, bottom: -22, width: "100%" }} />
            </span>
          </h1>
        </div>
        {/* blue wave */}
        <div style={{ position: "relative", marginTop: 150 }}>
          <svg viewBox="0 0 1920 170" preserveAspectRatio="none" style={{ display: "block", width: "100%", height: 150 }}>
            <path d="M0 60 C 320 -10 760 -10 960 30 C 1180 75 1560 95 1920 30 L1920 170 L0 170 Z" fill={HERO.blue} />
          </svg>
          <div style={{ background: HERO.blue, paddingBottom: 70 }}>
            <div style={{ marginTop: -120, position: "relative", zIndex: 3 }}>
              <TicketForm />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

window.Icon_search = SearchGlyph;
Object.assign(window, { Hero, HERO });
