// sections.jsx — Skysham homepage content sections (brand-styled, from the wireframe)
const { useState: useSecState, useEffect: useSecEffect, useRef: useSecRef } = React;
const BLUE = "#1270C4", BLUE2 = "#1461FB", NAVY = "#0A1730", ORANGE = "#F47C20";

const wrap = { maxWidth: 1500, margin: "0 auto", padding: "0 56px" };
const gradBtn = { border: "none", cursor: "pointer", borderRadius: 999, padding: "13px 28px",
                  background: `linear-gradient(180deg, ${BLUE2}, ${BLUE})`, color: "#fff",
                  font: "700 15px var(--font-ui)", boxShadow: "0 10px 22px rgba(18,112,196,.32)" };
const outlineBtn = { border: `1.5px solid ${BLUE}`, background: "#fff", cursor: "pointer", borderRadius: 999,
                     padding: "12px 24px", color: BLUE, font: "700 14px var(--font-ui)", whiteSpace: "nowrap" };

function SectionHead({ title, sub, action, center, light }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: center ? "center" : "space-between",
                  textAlign: center ? "center" : "left", marginBottom: 36, flexDirection: center ? "column" : "row" }}>
      <div>
        <h2 style={{ font: "800 42px/1 var(--font-ui)", color: light ? "#fff" : NAVY, margin: 0, letterSpacing: "-.01em" }}>{title}</h2>
        {sub && <p style={{ font: "500 16px var(--font-ui)", color: light ? "rgba(255,255,255,.8)" : "#6B7488", margin: "12px 0 0" }}>{sub}</p>}
      </div>
      {action && <button style={outlineBtn}>{action}</button>}
    </div>
  );
}

function Pill({ children, tone }) {
  const map = { blue: [BLUE, "#fff"], green: ["#1F8A5B", "#fff"], orange: [ORANGE, "#fff"], red: ["#EF4444", "#fff"] };
  const [bg, fg] = map[tone] || map.blue;
  return <span style={{ position: "absolute", top: 14, left: 14, background: bg, color: fg, font: "700 11px var(--font-ui)",
                        padding: "6px 12px", borderRadius: 999, letterSpacing: ".02em", zIndex: 2 }}>{children}</span>;
}

// Destination / trip / hotel image area — a drop-zone for the user's real 3D PNG / photo
function Photo({ id, label, h = 200 }) {
  return (
    <div style={{ position: "relative", height: h }}>
      <image-slot id={id} shape="rect" placeholder={label}
        style={{ display: "block", width: "100%", height: "100%",
                 background: "linear-gradient(135deg,#E5EEF8,#CBD9EA)", color: "#8AA0BC", font: "600 13px var(--font-ui)" }}></image-slot>
    </div>
  );
}

function Stat({ n, l }) {
  return (
    <div style={{ flex: 1, textAlign: "center" }}>
      <div style={{ font: "800 46px var(--font-ui)", color: BLUE, lineHeight: 1 }}>{n}</div>
      <div style={{ font: "600 14px var(--font-ui)", color: "#6B7488", marginTop: 8 }}>{l}</div>
    </div>
  );
}
function StatsBar() {
  return (
    <section data-char="load" style={{ ...wrap, marginTop: 56 }}>
      <div style={{ background: "#fff", border: "1px solid #E9EFF6", borderRadius: 22, boxShadow: "0 14px 36px rgba(10,23,48,.07)",
                    display: "flex", padding: "30px 20px", gap: 0, divide: 1 }}>
        {[["500+", "Destinations"], ["120+", "Airlines"], ["10K+", "Hotels"], ["2M+", "Happy Travelers"]].map(([n, l], i) => (
          <React.Fragment key={l}>
            {i > 0 && <div style={{ width: 1, background: "#EEF2F7" }} />}
            <Stat n={n} l={l} />
          </React.Fragment>
        ))}
      </div>
    </section>
  );
}

function DestCard({ id, place, sub, price, rating, badge, badgeTone, tall }) {
  const [h, setH] = useSecState(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
         style={{ background: "#fff", borderRadius: 18, overflow: "hidden", border: "1px solid #EEF2F7",
                  boxShadow: h ? "0 20px 44px rgba(10,23,48,.16)" : "0 6px 18px rgba(10,23,48,.06)",
                  transform: h ? "translateY(-5px)" : "none", transition: "all .18s ease", cursor: "pointer" }}>
      <div style={{ position: "relative" }}>
        {badge && <Pill tone={badgeTone}>{badge}</Pill>}
        <Photo id={id} label="Drop 3D render / photo" h={tall ? 230 : 190} />
      </div>
      <div style={{ padding: 18 }}>
        <div style={{ font: "700 17px var(--font-ui)", color: NAVY }}>{place}</div>
        <div style={{ font: "500 13px var(--font-ui)", color: "#7A8499", margin: "6px 0 14px", lineHeight: 1.5 }}>{sub}</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ font: "800 18px var(--font-ui)", color: BLUE }}>{price} <small style={{ font: "400 12px var(--font-ui)", color: "#9AA3B5" }}>/person</small></div>
          <Stars value={rating} />
        </div>
      </div>
    </div>
  );
}

function PopularDestinations() {
  const d = [
    ["dest-dubai", "Dubai, UAE", "City of luxury, adventure and culture", "From $299", 5, "Popular", "blue"],
    ["dest-ist", "Istanbul, Turkey", "Where Europe meets Asia", "From $199", 4, "Deal", "green"],
    ["dest-paris", "Paris, France", "The city of love and lights", "From $450", 5, null, null],
    ["dest-bkk", "Bangkok, Thailand", "Temples, street food and nightlife", "From $349", 4, "Hot", "orange"],
  ];
  return (
    <section style={{ ...wrap, marginTop: 88 }}>
      <SectionHead title="Popular Destinations" sub="Top picks loved by travelers worldwide" action="View All Destinations →" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 22 }}>
        {d.map((x) => <DestCard key={x[0]} id={x[0]} place={x[1]} sub={x[2]} price={x[3]} rating={x[4]} badge={x[5]} badgeTone={x[6]} tall />)}
      </div>
    </section>
  );
}

function FlightDealRow({ code, route, info, date, price, note, noteColor }) {
  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: "18px 26px", display: "flex", alignItems: "center",
                  gap: 24, boxShadow: "0 4px 14px rgba(10,23,48,.06)", border: "1px solid #EEF2F7" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 16, flex: "1 1 0" }}>
        <div style={{ width: 46, height: 46, borderRadius: 10, background: "var(--blue-surface)", display: "flex",
                      alignItems: "center", justifyContent: "center", font: "800 13px var(--font-ui)", color: BLUE }}>{code}</div>
        <div><div style={{ font: "700 16px var(--font-ui)", color: NAVY }}>{route}</div>
             <div style={{ font: "500 12px var(--font-ui)", color: "#8A93A6", marginTop: 3 }}>{info}</div></div>
      </div>
      <div style={{ font: "500 13px var(--font-ui)", color: "#8A93A6", flex: "0 0 110px" }}>{date}</div>
      <div style={{ textAlign: "right", flex: "0 0 130px" }}>
        <div style={{ font: "800 22px var(--font-ui)", color: BLUE }}>{price}</div>
        <div style={{ font: "600 11px var(--font-ui)", color: noteColor, marginTop: 2 }}>{note}</div>
      </div>
      <button style={{ ...gradBtn, padding: "10px 22px", fontSize: 13 }}>Book Now</button>
    </div>
  );
}
function FlightDeals() {
  const rows = [
    ["EK", "Dubai → London", "Emirates · Direct · 7h 20m", "25 Mar 2024", "$420", "🔥 -30% today only", "#22A35B"],
    ["TK", "Dubai → Istanbul", "Turkish Airlines · Direct · 4h 30m", "20 Mar 2024", "$165", "🔥 Best price this month", "#22A35B"],
    ["EY", "Dubai → Paris", "Etihad · 1 Stop · 9h 10m", "1 Apr 2024", "$510", "⚡ Limited seats", "#F59E0B"],
  ];
  return (
    <section style={{ background: "#F4FAFF", padding: "80px 0", marginTop: 88 }}>
      <div style={wrap}>
        <SectionHead title="Today's Best Flight Deals" sub="Prices updated every hour — book before they're gone" action="See All Flights →" />
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {rows.map((r, i) => <FlightDealRow key={i} code={r[0]} route={r[1]} info={r[2]} date={r[3]} price={r[4]} note={r[5]} noteColor={r[6]} />)}
        </div>
      </div>
    </section>
  );
}

function FeaturedTrips() {
  const t = [
    ["trip-morocco", "Discover Morocco", "Marrakech, Fes, Sahara Desert", "$899", 5, "7 Days", "blue"],
    ["trip-greece", "Greek Islands Escape", "Athens, Santorini, Mykonos", "$1,299", 5, "10 Days", "green"],
    ["trip-tokyo", "Tokyo City Break", "Culture, cuisine & cherry blossoms", "$1,099", 4, "5 Days", "orange"],
  ];
  return (
    <section data-char="trips" style={{ ...wrap, marginTop: 88 }}>
      <SectionHead title="Featured Trip Packages" sub="Handpicked experiences for every type of traveler" action="Browse All Trips →" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 22 }}>
        {t.map((x) => <DestCard key={x[0]} id={x[0]} place={x[1]} sub={x[2]} price={x[3]} rating={x[4]} badge={x[5]} badgeTone={x[6]} />)}
      </div>
    </section>
  );
}

function HotelCard({ id, name, sub, price, badge, badgeTone }) {
  const [h, setH] = useSecState(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
         style={{ background: "#fff", borderRadius: 18, overflow: "hidden", border: "1px solid #EEF2F7",
                  boxShadow: h ? "0 18px 40px rgba(10,23,48,.15)" : "0 6px 18px rgba(10,23,48,.06)",
                  transform: h ? "translateY(-4px)" : "none", transition: "all .18s ease" }}>
      <div style={{ position: "relative" }}>
        {badge && <Pill tone={badgeTone}>{badge}</Pill>}
        <Photo id={id} label="Drop hotel photo" h={170} />
      </div>
      <div style={{ padding: 18 }}>
        <div style={{ font: "700 16px var(--font-ui)", color: NAVY }}>{name}</div>
        <div style={{ font: "500 13px var(--font-ui)", color: "#7A8499", margin: "6px 0 14px" }}>{sub}</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ font: "800 18px var(--font-ui)", color: BLUE }}>{price}<small style={{ font: "400 12px var(--font-ui)", color: "#9AA3B5" }}>/night</small></div>
          <button style={{ ...gradBtn, padding: "8px 18px", fontSize: 13 }}>View</button>
        </div>
      </div>
    </div>
  );
}
function TopHotels() {
  const h = [
    ["hotel-burj", "Burj Al Arab, Dubai", "Iconic luxury on the water", "$800", "★★★★★", "blue"],
    ["hotel-fs", "Four Seasons Istanbul", "Bosphorus views, world-class dining", "$320", "Free Cancel", "green"],
    ["hotel-paris", "Le Méridien Paris", "Steps from the Eiffel Tower", "$280", null, null],
    ["hotel-maldives", "Conrad Maldives", "Overwater bungalows, crystal waters", "$950", "Last 2 rooms!", "orange"],
  ];
  return (
    <section style={{ ...wrap, marginTop: 88 }}>
      <SectionHead title="Top Rated Hotels" sub="Verified reviews from real travelers" action="Search All Hotels →" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 22 }}>
        {h.map((x) => <HotelCard key={x[0]} id={x[0]} name={x[1]} sub={x[2]} price={x[3]} badge={x[4]} badgeTone={x[5]} />)}
      </div>
    </section>
  );
}

Object.assign(window, { SectionHead, Pill, Photo, StatsBar, PopularDestinations, FlightDeals, FeaturedTrips, TopHotels,
                        wrap, gradBtn, outlineBtn, BLUE, BLUE2, NAVY, ORANGE });
