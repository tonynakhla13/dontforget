// sections2.jsx — Explore by Region, Rewards, Travel Tools, Trust, Footer
const { useState: useSec2State } = React;

function RegionCard({ emoji, name, cities, line }) {
  const [h, setH] = useSec2State(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
         style={{ background: "#fff", borderRadius: 16, padding: 24, cursor: "pointer",
                  boxShadow: h ? "0 14px 32px rgba(10,23,48,.12)" : "0 4px 14px rgba(10,23,48,.05)",
                  border: "1px solid #EEF2F7", transform: h ? "translateY(-3px)" : "none", transition: "all .16s" }}>
      <div style={{ fontSize: 30, marginBottom: 12 }}>{emoji}</div>
      <div style={{ font: "700 16px var(--font-ui)", color: NAVY, marginBottom: 6 }}>{name}</div>
      <div style={{ font: "500 13px var(--font-ui)", color: "#8A93A6", marginBottom: 14 }}>{cities}</div>
      <div style={{ font: "700 13px var(--font-ui)", color: BLUE }}>{line} →</div>
    </div>
  );
}

function ExploreRegion() {
  const r = [
    ["🕌", "Middle East", "Dubai, Istanbul, Cairo, Amman", "45 trips from $199"],
    ["🏰", "Europe", "Paris, Rome, Barcelona, London", "120 trips from $299"],
    ["🏯", "Asia", "Tokyo, Bali, Bangkok, Singapore", "98 trips from $449"],
    ["🗽", "Americas", "New York, Cancun, Miami, Rio", "67 trips from $599"],
  ];
  const regions = [["🌍 Middle East", "45 trips"], ["🌍 Europe", "120 trips"], ["🌏 Asia", "98 trips"], ["🌎 Americas", "67 trips"]];
  return (
    <section style={{ ...wrap, marginTop: 88 }}>
      <SectionHead title="Explore by Region" sub="Pick a region to discover destinations and packages" action="View All Regions →" />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div style={{ position: "relative", borderRadius: 18, overflow: "hidden", minHeight: 380 }}>
          <image-slot id="region-map" shape="rect" placeholder="Drop world-map / 3D globe render"
            style={{ display: "block", width: "100%", height: "100%", minHeight: 380,
                     background: "linear-gradient(135deg,#E5EEF8,#CBD9EA)", color: "#8AA0BC", font: "600 13px var(--font-ui)" }}></image-slot>
          <div style={{ position: "absolute", top: 22, left: 24, background: "#fff", borderRadius: 12, padding: "16px 18px",
                        boxShadow: "0 10px 26px rgba(10,23,48,.16)" }}>
            <div style={{ font: "700 11px var(--font-ui)", letterSpacing: ".06em", color: "#8A93A6", marginBottom: 8 }}>POPULAR REGIONS</div>
            {regions.map(([n, t]) => (
              <div key={n} style={{ display: "flex", justifyContent: "space-between", gap: 24, font: "600 13px var(--font-ui)", color: BLUE, padding: "5px 0", cursor: "pointer" }}>
                <span>{n}</span><span style={{ color: "#9AA3B5" }}>{t}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          {r.map((x) => <RegionCard key={x[1]} emoji={x[0]} name={x[1]} cities={x[2]} line={x[3]} />)}
        </div>
      </div>
    </section>
  );
}

function Rewards() {
  const tiers = [
    ["🥉", "Silver", "0 – 5,000 pts", "Basic perks", false],
    ["🥇", "Gold ← You're here", "5,000 – 20,000 pts", "Priority support", true],
    ["💎", "Platinum", "20,000+ pts", "Lounge access + upgrades", false],
  ];
  return (
    <section data-char="reward" style={{ background: "linear-gradient(135deg,#0A1730,#10254A 55%,#163C7A)", padding: "84px 0", marginTop: 88 }}>
      <div style={{ ...wrap, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }}>
        <div style={{ color: "#fff" }}>
          <span style={{ display: "inline-block", background: "linear-gradient(135deg,#F47C20,#FFB347)", color: "#1A1A1A",
                         padding: "7px 16px", borderRadius: 999, font: "800 12px var(--font-ui)", letterSpacing: ".08em", marginBottom: 18 }}>SKYSHAM REWARDS</span>
          <h2 style={{ font: "800 42px/1.15 var(--font-ui)", margin: "0 0 16px" }}>Earn Points on Every Booking</h2>
          <p style={{ font: "500 16px/1.7 var(--font-ui)", color: "rgba(255,255,255,.78)", margin: "0 0 30px", maxWidth: 460 }}>
            Join Skysham Rewards and earn points on flights, hotels and trips. Redeem for free stays, upgrades and exclusive perks.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, marginBottom: 30 }}>
            {[["1x", "per $1 on flights"], ["2x", "points on hotels"], ["3x", "points on packages"]].map(([n, l]) => (
              <div key={n} style={{ background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.12)", borderRadius: 14, padding: "20px 12px", textAlign: "center" }}>
                <div style={{ font: "800 30px var(--font-ui)", color: "#FFB347" }}>{n}</div>
                <div style={{ font: "500 12px var(--font-ui)", color: "rgba(255,255,255,.7)", marginTop: 6 }}>{l}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <button style={{ border: "none", cursor: "pointer", borderRadius: 12, padding: "14px 30px",
                             background: "linear-gradient(135deg,#F47C20,#FFB347)", color: "#1A1A1A", font: "800 15px var(--font-ui)" }}>Join Free Now</button>
            <button style={{ border: "2px solid rgba(255,255,255,.3)", background: "transparent", cursor: "pointer",
                             borderRadius: 12, padding: "14px 30px", color: "#fff", font: "700 15px var(--font-ui)" }}>Learn More</button>
          </div>
        </div>
        <div style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 20, padding: 30 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
            <span style={{ font: "700 16px var(--font-ui)", color: "#fff" }}>Member Tiers</span>
            <span style={{ font: "600 13px var(--font-ui)", color: "#FFB347", cursor: "pointer" }}>How it works →</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {tiers.map(([e, n, p, perk, on]) => (
              <div key={n} style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                       background: on ? "rgba(255,179,71,.14)" : "rgba(255,255,255,.07)",
                       border: on ? "1px solid rgba(255,179,71,.35)" : "1px solid transparent", borderRadius: 12, padding: "15px 18px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 34, height: 34, borderRadius: 999, background: "rgba(255,255,255,.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>{e}</div>
                  <div><div style={{ font: "700 14px var(--font-ui)", color: on ? "#FFB347" : "#fff" }}>{n}</div>
                       <div style={{ font: "500 12px var(--font-ui)", color: "rgba(255,255,255,.5)" }}>{p}</div></div>
                </div>
                <span style={{ font: "600 12px var(--font-ui)", color: on ? "#FFB347" : "rgba(255,255,255,.6)" }}>{perk}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustBadges() {
  const b = [
    ["🔒", "#EFF6FF", "Secure Payments", "256-bit SSL encryption on all transactions"],
    ["✅", "#F0FDF4", "Best Price Guarantee", "Find it cheaper? We'll match it + 10% off"],
    ["💰", "#FFF6ED", "Free Cancellation", "Cancel for free up to 24h before departure"],
    ["📞", "#FFF1F2", "24/7 Support", "Real humans available any time, any day"],
    ["🏆", "#F5F3FF", "Award Winning", "Best Travel Platform 2023 — Arab Travel Awards"],
  ];
  return (
    <section style={{ background: "#F4FAFF", padding: "72px 0", marginTop: 0 }}>
      <div style={wrap}>
        <SectionHead center title="Book with Confidence" sub="Your security and satisfaction are our top priority" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 20 }}>
          {b.map(([e, bg, t, d]) => (
            <div key={t} style={{ background: "#fff", borderRadius: 16, padding: "28px 20px", textAlign: "center",
                                  boxShadow: "0 4px 14px rgba(10,23,48,.06)", border: "1px solid #EEF2F7" }}>
              <div style={{ width: 56, height: 56, borderRadius: 999, background: bg, display: "flex", alignItems: "center",
                            justifyContent: "center", fontSize: 24, margin: "0 auto 16px" }}>{e}</div>
              <div style={{ font: "700 14px var(--font-ui)", color: NAVY, marginBottom: 8 }}>{t}</div>
              <div style={{ font: "500 12px/1.6 var(--font-ui)", color: "#8A93A6" }}>{d}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTABanner() {
  return (
    <section style={{ ...wrap, marginTop: 88 }}>
      <div style={{ position: "relative", overflow: "hidden", borderRadius: 28, padding: "64px 60px",
                    background: "linear-gradient(120deg,#1461FB,#1270C4 60%,#0E4F94)" }}>
        <div style={{ position: "absolute", right: -40, top: -60, width: 320, height: 320, borderRadius: 999, background: "rgba(255,255,255,.08)" }} />
        <div style={{ position: "relative", maxWidth: 620, color: "#fff" }}>
          <h2 style={{ font: "800 40px/1.1 var(--font-ui)", margin: "0 0 14px" }}>Ready for your next adventure?</h2>
          <p style={{ font: "500 16px/1.7 var(--font-ui)", color: "rgba(255,255,255,.85)", margin: "0 0 28px" }}>
            Tell us where you want to go — our travel consultants will craft the perfect journey. No payment online, just an inquiry.
          </p>
          <div style={{ display: "flex", gap: 12 }}>
            <button style={{ border: "none", cursor: "pointer", borderRadius: 999, padding: "15px 34px", background: "#fff", color: BLUE, font: "800 16px var(--font-ui)" }}>Send an Inquiry →</button>
            <button style={{ border: "2px solid rgba(255,255,255,.5)", background: "transparent", cursor: "pointer", borderRadius: 999, padding: "15px 30px", color: "#fff", font: "700 16px var(--font-ui)" }}>Talk to a Consultant</button>
          </div>
        </div>
      </div>
    </section>
  );
}

function SiteFooter() {
  const cols = [
    ["Company", ["About Us", "Careers", "Press", "Contact"]],
    ["Services", ["Flights", "Hotels", "Trips", "Visa"]],
    ["Support", ["Help Center", "Privacy Policy", "Terms of Use"]],
  ];
  return (
    <footer style={{ background: "linear-gradient(180deg,#0A1730,#091222)", color: "#9AA7BC", marginTop: 88 }}>
      <div style={{ ...wrap, display: "grid", gridTemplateColumns: "1.6fr 1fr 1fr 1fr", gap: 40, padding: "60px 56px 36px" }}>
        <div>
          <div style={{ background: "#fff", borderRadius: 14, padding: 8, display: "inline-flex", boxShadow: "0 6px 18px rgba(0,0,0,.25)" }}>
            <img src="assets/sky-sham-logo.png" alt="Sky Sham" style={{ height: 56, width: 56, objectFit: "contain" }} />
          </div>
          <p style={{ font: "500 14px/1.7 var(--font-ui)", color: "#8493AB", margin: "18px 0 0", maxWidth: 280 }}>
            Your all-in-one travel platform for flights, hotels, trips and visa services.
          </p>
        </div>
        {cols.map(([h, items]) => (
          <div key={h}>
            <div style={{ font: "700 14px var(--font-ui)", color: "#fff", marginBottom: 16 }}>{h}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
              {items.map((i) => <a key={i} href="#" style={{ font: "500 14px var(--font-ui)", color: "#8493AB", textDecoration: "none" }}>{i}</a>)}
            </div>
          </div>
        ))}
      </div>
      <div style={{ borderTop: "1px solid rgba(255,255,255,.08)", padding: "20px 56px", textAlign: "center", font: "500 13px var(--font-ui)", color: "#6B7793" }}>
        © 2026 Skysham · Sama Al Sham Travel &amp; Tours. All rights reserved.
      </div>
    </footer>
  );
}

Object.assign(window, { ExploreRegion, Rewards, TrustBadges, CTABanner, SiteFooter });
